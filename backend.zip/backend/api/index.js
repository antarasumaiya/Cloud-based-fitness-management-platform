import app from "../app.js";

export default app;
